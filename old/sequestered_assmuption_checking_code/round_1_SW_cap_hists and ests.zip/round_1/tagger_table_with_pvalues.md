# Tagger Comparison: CJS Survival Estimates and F-test Results

## a. Rock Island Tailrace (_R_1)

### Chinook (CHN)

|Reach|Tagger A: Estimate|Tagger A: SE|Tagger B: Estimate|Tagger B: SE|Tagger C: Estimate|Tagger C: SE|P-value (F-test)|
|---|---|---|---|---|---|---|---|
|Release to CB|0.9848|0.0067|0.9881|0.0059|0.991|0.0052|0.764|
|CB to Sunland|0.9815|0.0075|0.9819|0.0073|0.9939|0.0043|0.355|
|Sunland to Wanapum|0.9342|0.0139|0.9446|0.0127|0.9361|0.0136|0.842|
|Wanapum to Mattawa|0.906|0.0169|0.899|0.0172|0.9013|0.0171|0.206|
|Mattawa to Priest Rapids|0.9777|0.009|0.9714|0.0101|0.9491|0.0133|0.161|
|Priest Rapids to Lower Ringold|0.9163|0.0171|0.9101|0.0175|0.9004|0.0185|0.947|

### Steelhead (STH)

|Reach|Tagger A: Estimate|Tagger A: SE|Tagger B: Estimate|Tagger B: SE|Tagger C: Estimate|Tagger C: SE|P-value (F-test)|
|---|---|---|---|---|---|---|---|
|Release to CB|0.9849|0.0067|0.9815|0.0075|0.9874|0.0072|0.842|
|CB to Sunland|0.9969|0.0031|0.9937|0.0044|0.9915|0.0060|0.382|
|Sunland to Wanapum|0.9233|0.0147|0.9054|0.0164|0.8112|0.0256|<0.001|
|Wanapum to Mattawa|0.9269|0.0150|0.9164|0.0163|0.9055|0.0214|0.0216|
|Mattawa to Priest Rapids|0.9466|0.0135|0.8897|0.0193|0.8706|0.0257|0.0246|
|Priest Rapids to Lower Ringold|0.9163|0.0171|0.8889|0.0205|0.8592|0.0285|0.100|

## b. Priest Rapids Tailrace (_R_2)

### Chinook (CHN)

|Reach|Tagger A: Estimate|Tagger A: SE|Tagger B: Estimate|Tagger B: SE|Tagger C: Estimate|Tagger C: SE|P-value (F-test)|
|---|---|---|---|---|---|---|---|
|Release to Lower Ringold|0.9025|0.0178|0.8527|0.0207|0.84|0.0221|0.0723|

### Steelhead (STH)

|Reach|Tagger A: Estimate|Tagger A: SE|Tagger B: Estimate|Tagger B: SE|Tagger C: Estimate|Tagger C: SE|P-value (F-test)|
|---|---|---|---|---|---|---|---|
|Release to Lower Ringold|0.8598|0.0211|0.852|0.0208|0.7473|0.0322|0.0021|
