Cormack-Jolly-Seber Report

Survival Estimates:

|   |   |   |
|---|---|---|
||Release to Lower Ringold|   |
||Estimate|s.e.|
|Priest Rapids Tailrace CHN|0.8649|0.011765|

Capture Estimates:

|   |   |   |   |   |
|---|---|---|---|---|
||Lower Ringold|   |Hanford Survival*Capture|   |
||Estimate|s.e.|Estimate|s.e.|
|Priest Rapids Tailrace CHN|1.0000|0.000000|0.9808|0.005076|

Configuration:

|   |   |
|---|---|
|Dataset|PR_tagger_comparison_ATLAS|
|Groups|R1: Priest Rapids Tailrace CHN|
|Active Detection Sites|A0: Lower Ringold|
|A1: Hanford|
|Optimizer|Fletch, maxIterations=200, stepSize=1e-06, precision=1e-06|
|Survival parameters logististically constrained|none|
|Capture parameters fixed at 1.0|none|